from django.apps import AppConfig


class BuySellConfig(AppConfig):
    name = 'buy_sell'
