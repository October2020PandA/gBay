from django.shortcuts import render, redirect, HttpResponse
from .models import *
import random
# Create your views here.

def index(request):
    if 'price' not in request.session:
        request.session['price'] = []
    if 'cart' not in request.session:
        request.session['cart'] = []
    if 'cart2' not in request.session:
        request.session['cart2'] = []
    if 'total' not in request.session:
        request.session['total'] = 0

    pro = Product.objects.all()
    price = request.session['price']
    cart = request.session['cart']
    cart2 = request.session['cart2']
    total = request.session['total']
    mylist = zip(pro,price)
    context = {
        'mylist': mylist,
        'cart': cart,
        'cart2': cart2,
        'total':total,
    }
    return render(request, 'index.html', context)

def update(request):
    if 'price' not in request.session:
        request.session['price'] = []
    if 'cart' not in request.session:
        request.session['cart'] = []
    if 'cart2' not in request.session:
        request.session['cart2'] = []
    if 'total' not in request.session:
        request.session['total'] = 0

    pro = Product.objects.all()
    price = request.session['price']
    cart = request.session['cart']
    cart2 = request.session['cart2']
    total = request.session['total']
    mylist = zip(pro,price)
    context = {
        'mylist': mylist,
        'cart': cart,
        'cart2': cart2,
        'total':total,
    }
    return render(request, 'update.html', context)

def success(request):
    if 'price' not in request.session:
        request.session['price'] = []
    if 'cart' not in request.session:
        request.session['cart'] = []
    if 'cart2' not in request.session:
        request.session['cart2'] = []
    if 'total' not in request.session:
        request.session['total'] = 0

    pro = Product.objects.all()
    price = request.session['price']
    cart = request.session['cart']
    cart2 = request.session['cart2']
    total = request.session['total']
    mylist = zip(pro,price)
    context = {
        'mylist': mylist,
        'cart': cart,
        'cart2': cart2,
        'total':total,
    }
    return render(request, 'success.html', context)

def create(request):
    Product.objects.create(
        title = request.POST['title'], 
        price = request.POST['price'],
    )
    pro = Product.objects.all()
    price = []
    total = 0
    for i in pro:
        price.append(i.price)
    for i in pro:
        total = total+i.price
    request.session['total'] = total
    random.shuffle(price)
    request.session['price'] = price
    return redirect('/update')

def jumble(request):
    pro = Product.objects.all()
    price = []
    total = 0
    for i in pro:
        price.append(i.price)
    for i in pro:
        total = total+i.price
    request.session['total'] = total
    random.shuffle(price)
    request.session['price'] = price
    return redirect('/update')



def delete(request,id):
    pro = Product.objects.get(id=id)
    pro.delete()
    pro = Product.objects.all()
    price = []
    total = 0
    for i in pro:
        price.append(i.price)
    for i in pro:
        total = total+i.price
    request.session['total'] = total
    random.shuffle(price)
    request.session['price'] = price
    return redirect('/update')

def reset(request):
    request.session.clear()
    return redirect('/')

def addtocart(request, title, rprice, price):
    item = title
    real = rprice
    fake = price
    carti = []
    carti.append(item)
    carti.append(fake)
    carti.append(real)
    request.session['cart'] = carti
    return redirect('/update')

def match(request, title, rprice, price):
    item = title
    real = int(rprice)
    fake = int(price)
    carti = []
    carti.append(item)
    carti.append(fake)
    carti.append(real)
    request.session['cart2'] = carti
    return redirect('/update')
        
def buy(request):
    carti = request.session['cart']
    b = request.session['cart2']
    total = request.session['total']
    summ = int(carti[2])
    print(summ)
    
    if carti[1] == b[2]:
        print('match')
        total = total - summ
        if total < 0:
            total = 0
            request.session['total'] = total
        else:
            request.session['total'] = total
        print(total)
    else:    
        print('no match')
        total = total + summ
        request.session['total'] = total
    if total == 0:
        request.session.clear()
        return redirect('/success')
    return redirect('/update')

