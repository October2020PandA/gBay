$(document).ready(function(){
    $('.match1').hover(function(){
        // $(this).next().toggle();
        console.log('clicked match1');
    });
});