from django.urls import path
from . import views

urlpatterns=[
    path('', views.index),
    path('create', views.create),
    path('jumble', views.jumble),
    path('delete/<int:id>', views.delete),
    path('add/<str:title>/<int:rprice>/<int:price>', views.addtocart),
    path('add2/<str:title>/<int:rprice>/<int:price>', views.match),
    path('reset',views.reset),
    path('update', views.update),
    path('buy', views.buy),
    path('success', views.success)
]